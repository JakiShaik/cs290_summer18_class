var express = require('express');
var axios = require('axios');
var router = express.Router();
const fs = require("fs");
const FILE = "mytextfile.txt";

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/cs290info',function(req,res) {
  res.send({
    "Course":"CS290",
    "Credits":4,
    "location":"KEC1003"
  });
})
router.get('/demo', function (req, res, next) {
  users= ['a','b'];
  usersJson = {'name':'John','id':'1'}
  res.render('demo.pug', { myusers: users,myusersJson: usersJson, title: "Happy, happy!" });
  });

router.get('/details',function(req,res){
  usersJson = {'name':'Dave','course':'cs290','id':'1'}
  res.render('details.pug', {myusersJson: usersJson });
});

router.get('/formGet',function(req,res){
  //303d25497d2a6ae3416269815741dd01
  var weatherData = {}
  axios.get('http://api.openweathermap.org/data/2.5/weather?id=5720727&appid=cc308818be6d460dbc5c45890a2cc303').then(function(data){
    console.log(data.data);
    console.log(data.data.main.temp);
    weatherData.temp = data.data.main.temp;
    res.render('weather',{data:weatherData});
  }).catch( function(err) {
    console.log(err);
  })

});

router.post('/formPost',function(req,res){
  //write(JSON.stringify(req.body));  
  console.log(req.body);
  var mixed = req.body.username;
  console.log('mixed is '+mixed);
  fs.writeFile("../public/mytextfile.txt", mixed, {encoding:'utf8'}, (err)=> {if (err) throw err;res.render('postInfo',req.body);});
});

/*router.get('/formGet',function(req,res){
  //API calling
  console.log(req.query);
  res.render('getInfo');
});*/
module.exports = router;

