var express = require('express');
var router = express.Router();
var courseModel = require('../models/course');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/courseList', function(req, res, next) {
  courseModel.retrieveCoursesData((err, results) => {
    if (err) throw err;
    console.log(results);
    res.render('course-list', { courses: results});
})
});

module.exports = router;
