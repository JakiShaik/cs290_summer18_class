for (var i = 0; i < process.argv.length; i++) {
    console.log(i, process.argv[i]);
    }
    